function q=kdelta(i,j)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% kdelta.m
% this function calculates the Kroneker Delta of two variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

if i==j,
   q=1;
else
   q=0;
end
