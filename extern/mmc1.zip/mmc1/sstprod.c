/* Simple wrapper function for building repop for different input types */
#include "mxInfo.h" /* for the type enum */
#define XDTYPE SINGLE_DTYPE
#define YDTYPE SINGLE_DTYPE
#include "tprod.c"
